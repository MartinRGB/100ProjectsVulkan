Tutorial 4 - Opening a window
=============================
Create and clear a vulkan window to draw


