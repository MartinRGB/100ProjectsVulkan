/******************************************************************************

 @File         main.m

 @Title        

 @Version     

 @Copyright    Copyright (c) Imagination Technologies Limited.

 @Platform     

 @Description  

******************************************************************************/
#import <UIKit/UIKit.h>

int main(int argc, char * argv[]) {
	@autoreleasepool {
		return UIApplicationMain(argc, argv, nil, @"AppDelegate");
	}
}

