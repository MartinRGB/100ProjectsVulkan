//
//  main.m
//
//  Created by Bill Hollings on 2015/07/30.
//  Copyright © 2015 The Brenwill Workshop Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	return NSApplicationMain(argc, argv);
}
