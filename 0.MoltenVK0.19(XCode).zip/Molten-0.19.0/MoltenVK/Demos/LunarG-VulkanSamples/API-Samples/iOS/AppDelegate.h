//
//  AppDelegate.h
//
//  Created by Bill Hollings on 2015/06/03.
//  Copyright (c) 2015 The Brenwill Workshop Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

